#algebre #ba1 #matrice 
# Definition
Fondamentalement, une matrice est tableau qui contient des choses. En mathématiques, ces choses seront des nombres(en tout cas à ce que je sache). En algebre, on va s'interesser a certaines matrices qui ont des propriétés interessantes.
Dans le cadre du cours d'algebre, les matrices sont des tableaux en 2 dimensions notés $n*p$ $n$ le nombre de lignes et $p$ le nombre de colonnes .
## Operations sur les matrices
On peut effectuer plusieurs opérations sur les matrices.
L'addition: $\begin{pmatrix} a &b \\ c &d \end{pmatrix} +\begin{pmatrix} e &f \\ g &h \end{pmatrix}= \begin{pmatrix} a+e &b+f \\ c+g &d+h \end{pmatrix}$
La soustraction:$\begin{pmatrix} a &b \\ c &d \end{pmatrix} -\begin{pmatrix} e &f \\ g &h \end{pmatrix}= \begin{pmatrix} a-e &b-f \\ c-g &d-h \end{pmatrix}$.
On peut multiplier la matrice par un scalaire:
$$\alpha \begin{pmatrix} a &b \\ c &d \end{pmatrix} =\begin{pmatrix} \alpha a &\alpha b \\ \alpha c  &\alpha d \end{pmatrix}$$
Une matrice possède un [[Determinant]], qui possède des propriétés utiles pour notre matrice.
## Des matrices aux applications vectorielles

## Template et exemples de matrices
Voic une liste d'exemples de matrices à copier-coller