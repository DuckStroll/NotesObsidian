# NotesObsidian
mes notes sur Obsidian et les outils bonus
Ca me permet aussi de decouvrir GitHub
